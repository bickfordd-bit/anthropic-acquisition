# Bickford Acquisition Data Room

This package contains cryptographically verifiable proof of Bickford’s canon + ledger system.

Nothing here requires trust in the seller.

You may:
- Verify all file hashes via MANIFEST.json
- Validate canon integrity via CANON/canon-index.json + CANON/canon-hash-chain.txt
- Validate ledger integrity via LEDGER/ledger-export.jsonl + LEDGER/ledger-hash-chain.txt
- Inspect promotion proofs and safety checks in PROOFS/

If any artifact fails verification, the export is invalid.

Execution is law.
Memory is structure.
Learning is monotonic.
